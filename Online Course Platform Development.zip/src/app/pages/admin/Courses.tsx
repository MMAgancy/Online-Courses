import React, { useEffect, useState } from 'react';
import { apiClient } from '../../api/client';
import { Card, CardContent, CardHeader, CardTitle, Button, Input } from '../../components/ui';
import { Plus, Search, MoreVertical, Edit, Trash2, Video, FileText } from 'lucide-react';

export const AdminCourses = () => {
  const [courses, setCourses] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const data = await apiClient('/admin/courses');
      setCourses(data);
    } catch (error) {
      console.error('Failed to fetch courses:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إدارة الدورات</h2>
          <p className="text-sm text-gray-500 mt-1">تصفح وتعديل وإضافة دورات جديدة</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="w-5 h-5" />
          دورة جديدة
        </Button>
      </div>

      <div className="mb-6 flex gap-4 bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input className="pl-4 pr-10 bg-gray-50/50 border-gray-200" placeholder="البحث عن دورة..." />
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : courses.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-100">
          <Video className="mx-auto h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900">لا توجد دورات</h3>
          <p className="text-gray-500 mt-1">قم بإضافة دورتك الأولى للبدء</p>
          <Button className="mt-4" variant="secondary">إنشاء دورة</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Card key={course.id} className="overflow-hidden hover:shadow-lg transition-shadow border-gray-100 rounded-xl group">
              <div className="h-48 overflow-hidden bg-gray-100 relative">
                {course.thumbnail ? (
                  <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400">
                    <Video className="w-12 h-12" />
                  </div>
                )}
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-md text-xs font-bold text-gray-800 flex items-center shadow-sm">
                  ${course.price || 0}
                </div>
              </div>
              <CardHeader className="p-5 pb-0">
                <CardTitle className="text-xl font-bold text-gray-900 line-clamp-2 leading-tight mb-2">
                  {course.title}
                </CardTitle>
                <div className="flex items-center text-sm text-gray-500 mb-3 gap-2">
                  <span className="font-medium bg-blue-50 text-blue-700 px-2 py-0.5 rounded-md text-xs">المدرب: {course.instructor || 'غير محدد'}</span>
                </div>
              </CardHeader>
              <CardContent className="p-5 pt-0">
                <p className="text-sm text-gray-600 line-clamp-2 mb-4">
                  {course.description}
                </p>
                <div className="flex items-center justify-between text-xs text-gray-500 mb-4 bg-gray-50 p-2 rounded-lg border border-gray-100">
                  <div className="flex items-center gap-1">
                    <FileText className="w-4 h-4 text-indigo-400" />
                    <span>{course.sections?.length || 0} أقسام</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Video className="w-4 h-4 text-emerald-400" />
                    <span>
                      {course.sections?.reduce((acc: number, sec: any) => acc + (sec.lessons?.length || 0), 0) || 0} دروس
                    </span>
                  </div>
                </div>
                <div className="flex gap-2 border-t border-gray-100 pt-4">
                  <Button variant="secondary" className="flex-1 text-sm bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700">تعديل المحتوى</Button>
                  <Button variant="ghost" className="px-3 text-red-500 hover:text-red-700 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
