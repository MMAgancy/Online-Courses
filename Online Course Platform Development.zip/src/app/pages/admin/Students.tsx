import React, { useEffect, useState } from 'react';
import { apiClient } from '../../api/client';
import { Card, CardContent, CardHeader, CardTitle, Button, Input } from '../../components/ui';
import { Plus, Search, MoreVertical, Edit, Trash2 } from 'lucide-react';

export const AdminStudents = () => {
  const [students, setStudents] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newStudent, setNewStudent] = useState({ name: '', username: '', password: '' });

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const data = await apiClient('/admin/users');
      setStudents(data);
    } catch (error) {
      console.error('Failed to fetch students:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient('/admin/users', {
        method: 'POST',
        body: JSON.stringify(newStudent),
      });
      setShowAddModal(false);
      setNewStudent({ name: '', username: '', password: '' });
      fetchStudents();
    } catch (error) {
      console.error('Failed to add student:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إدارة الطلاب</h2>
          <p className="text-sm text-gray-500 mt-1">عرض، إضافة وتعديل بيانات الطلاب المسجلين</p>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="flex items-center gap-2">
          <Plus className="w-5 h-5" />
          طالب جديد
        </Button>
      </div>

      <Card className="shadow-sm border-gray-100 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row gap-4 justify-between items-center">
          <div className="relative w-full max-w-md">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input className="pl-4 pr-10 bg-white" placeholder="البحث عن طالب..." />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-600 text-sm border-b border-gray-100">
                <th className="py-4 px-6 font-medium">الاسم</th>
                <th className="py-4 px-6 font-medium">اسم المستخدم</th>
                <th className="py-4 px-6 font-medium">تاريخ التسجيل</th>
                <th className="py-4 px-6 font-medium">الحالة</th>
                <th className="py-4 px-6 font-medium w-24 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white text-gray-800">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-500">جاري التحميل...</td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-500">لا يوجد طلاب مسجلين.</td>
                </tr>
              ) : (
                students.map((student) => (
                  <tr key={student.id} className="hover:bg-blue-50/30 transition-colors">
                    <td className="py-4 px-6 font-medium flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">
                        {student.name?.charAt(0)}
                      </div>
                      {student.name}
                    </td>
                    <td className="py-4 px-6 text-gray-600">{student.username}</td>
                    <td className="py-4 px-6 text-gray-500 text-sm">2024/01/15</td>
                    <td className="py-4 px-6">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        نشط
                      </span>
                    </td>
                    <td className="py-4 px-6 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button className="text-gray-400 hover:text-blue-600 p-1 transition-colors"><Edit className="w-4 h-4" /></button>
                        <button className="text-gray-400 hover:text-red-600 p-1 transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Add Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <Card className="w-full max-w-md bg-white shadow-xl rounded-2xl border-0 overflow-hidden">
            <CardHeader className="bg-gray-50 border-b border-gray-100 pb-4">
              <CardTitle className="text-xl">إضافة طالب جديد</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleAddStudent} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">الاسم الكامل</label>
                  <Input 
                    value={newStudent.name}
                    onChange={(e) => setNewStudent({...newStudent, name: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">اسم المستخدم</label>
                  <Input 
                    value={newStudent.username}
                    onChange={(e) => setNewStudent({...newStudent, username: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">كلمة المرور</label>
                  <Input 
                    type="password"
                    value={newStudent.password}
                    onChange={(e) => setNewStudent({...newStudent, password: e.target.value})}
                    required
                  />
                </div>
                <div className="pt-4 flex gap-3">
                  <Button type="submit" className="flex-1">إضافة</Button>
                  <Button type="button" variant="secondary" className="flex-1" onClick={() => setShowAddModal(false)}>إلغاء</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};
