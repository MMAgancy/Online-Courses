import React from 'react';
import { Outlet, Link, useLocation } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { BookOpen, User, LogOut, LayoutDashboard } from 'lucide-react';
import { Button } from '../../components/ui';

export const StudentLayout = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const navigation = [
    { name: 'لوحة التحكم', href: '/student/dashboard', icon: LayoutDashboard },
    { name: 'دوراتي', href: '/student/dashboard', icon: BookOpen },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="text-blue-600 w-8 h-8" />
            <span className="font-bold text-xl text-gray-900">منصتي التعليمية</span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <User className="w-5 h-5" />
              <span className="font-medium">{user?.name}</span>
            </div>
            <Button variant="ghost" className="text-red-600 hover:bg-red-50 hover:text-red-700 p-2" onClick={logout}>
              <LogOut className="w-5 h-5 ml-1" />
              خروج
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </div>
    </div>
  );
};
