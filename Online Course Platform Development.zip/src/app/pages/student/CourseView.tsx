import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { apiClient } from '../../api/client';
import { PlayCircle, CheckCircle, ChevronDown, ChevronUp, Lock } from 'lucide-react';
import { Button, Card } from '../../components/ui';
import { cn } from '../../components/ui';

export const StudentCourseView = () => {
  const { id } = useParams();
  const [course, setCourse] = useState<any>(null);
  const [activeLesson, setActiveLesson] = useState<any>(null);
  const [expandedSections, setExpandedSections] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchCourse = async () => {
      try {
        const data = await apiClient(`/courses/${id}`);
        setCourse(data);
        if (data.sections && data.sections.length > 0) {
          setExpandedSections([data.sections[0].id]);
          if (data.sections[0].lessons && data.sections[0].lessons.length > 0) {
            setActiveLesson(data.sections[0].lessons[0]);
          }
        }
      } catch (error) {
        console.error('Failed to fetch course:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchCourse();
  }, [id]);

  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) =>
      prev.includes(sectionId)
        ? prev.filter((sId) => sId !== sectionId)
        : [...prev, sectionId]
    );
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!course) {
    return <div className="text-center p-8 text-xl font-medium">الدورة غير موجودة.</div>;
  }

  return (
    <div className="max-w-[1400px] mx-auto bg-gray-50 flex flex-col lg:flex-row gap-8 py-6 px-4 sm:px-6 h-[calc(100vh-80px)] overflow-hidden">
      
      {/* Video Area (Main) */}
      <div className="flex-1 flex flex-col h-full overflow-y-auto pr-2 rounded-xl">
        <div className="bg-black aspect-video w-full rounded-2xl overflow-hidden shadow-xl mb-6 relative group">
          {activeLesson ? (
            <video 
              key={activeLesson.id}
              className="w-full h-full object-contain bg-black"
              controls 
              controlsList="nodownload" 
              autoPlay
              src={activeLesson.videoUrl}
            >
              متصفحك لا يدعم تشغيل الفيديو.
            </video>
          ) : (
            <div className="flex items-center justify-center h-full text-white bg-gray-900 flex-col">
              <PlayCircle className="w-16 h-16 text-gray-400 mb-4" />
              <p>الرجاء اختيار درس للبدء.</p>
            </div>
          )}
        </div>

        <Card className="p-6 md:p-8 bg-white shadow-sm border border-gray-100 rounded-xl flex-1">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                {activeLesson ? activeLesson.title : 'لا يوجد درس محدد'}
              </h2>
              <div className="text-blue-600 font-medium bg-blue-50 px-3 py-1 rounded-md inline-block">
                دورة: {course.title}
              </div>
            </div>
            {activeLesson && (
              <Button variant="ghost" className="text-gray-500 gap-2">
                <CheckCircle className="w-5 h-5" />
                تحديد كمكتمل
              </Button>
            )}
          </div>
          <p className="mt-6 text-gray-600 leading-relaxed text-lg">
            {course.description}
          </p>
        </Card>
      </div>

      {/* Sidebar (Curriculum) */}
      <div className="w-full lg:w-96 flex-shrink-0 bg-white rounded-xl shadow-sm border border-gray-200 h-full flex flex-col">
        <div className="p-6 border-b border-gray-100 bg-gray-50 rounded-t-xl">
          <h3 className="font-bold text-xl text-gray-900">محتوى الدورة</h3>
          <p className="text-sm text-gray-500 mt-2">استمر في التعلم بخطى ثابتة</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {course.sections?.map((section: any, index: number) => {
            const isExpanded = expandedSections.includes(section.id);
            return (
              <div key={section.id} className="border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm">
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors text-right focus:outline-none"
                >
                  <span className="font-semibold text-gray-800">
                    القسم {index + 1}: {section.title}
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-500" />
                  )}
                </button>

                {isExpanded && (
                  <div className="divide-y divide-gray-100 bg-white">
                    {section.lessons?.map((lesson: any) => {
                      const isActive = activeLesson?.id === lesson.id;
                      return (
                        <button
                          key={lesson.id}
                          onClick={() => setActiveLesson(lesson)}
                          className={cn(
                            "w-full flex items-center gap-3 p-4 text-right hover:bg-blue-50 transition-colors focus:outline-none",
                            isActive ? "bg-blue-50 border-r-4 border-blue-600" : "border-r-4 border-transparent"
                          )}
                        >
                          <div className={cn("flex-shrink-0", isActive ? "text-blue-600" : "text-gray-400")}>
                            {isActive ? <PlayCircle className="w-5 h-5" /> : <PlayCircle className="w-5 h-5" />}
                          </div>
                          <div className="flex-1 text-sm font-medium pr-1">
                            <span className={cn(isActive ? "text-blue-800 font-bold" : "text-gray-700")}>
                              {lesson.title}
                            </span>
                          </div>
                          <div className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                            {lesson.duration || '00:00'}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
