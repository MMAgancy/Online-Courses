import React, { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { apiClient } from '../../api/client';
import { Card, CardContent, CardHeader, CardTitle, Button } from '../../components/ui';
import { PlayCircle, Clock, BookOpen, User } from 'lucide-react';

export const StudentDashboard = () => {
  const { user } = useAuth();
  const [courses, setCourses] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const data = await apiClient('/student/courses');
        setCourses(data);
      } catch (error) {
        console.error('Failed to fetch courses:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCourses();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 flex flex-col md:flex-row gap-6 items-center justify-between bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div>
          <h1 className="text-3xl font-bold mb-2">مرحباً بعودتك، {user?.name}! 👋</h1>
          <p className="text-blue-100 text-lg">استكمل تعلمك اليوم وحقق أهدافك.</p>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">الدورات المسجلة</h2>
        {courses.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
            <BookOpen className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">لا توجد دورات حالياً</h3>
            <p className="text-gray-500 mt-2">لم تقم بالتسجيل في أي دورة بعد.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <Card key={course.id} className="overflow-hidden flex flex-col hover:shadow-md transition-shadow">
                <div className="h-48 overflow-hidden bg-gray-200">
                  <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
                </div>
                <CardHeader className="flex-1">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                    <User className="w-4 h-4" />
                    <span>{course.instructor}</span>
                  </div>
                  <CardTitle className="text-xl mb-2 line-clamp-2">{course.title}</CardTitle>
                </CardHeader>
                <CardContent className="mt-auto pt-0 border-t border-gray-100">
                  <div className="py-4 flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">
                      تقدمك: {course.progress}%
                    </span>
                    <div className="w-32 bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${course.progress}%` }}></div>
                    </div>
                  </div>
                  <Link to={`/student/course/${course.id}`} className="block">
                    <Button className="w-full mt-2 group">
                      متابعة التعلم
                      <PlayCircle className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
