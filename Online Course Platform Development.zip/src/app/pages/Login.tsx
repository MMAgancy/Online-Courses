import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { Button, Input, Card, CardHeader, CardTitle, CardContent } from '../components/ui';
import { GraduationCap } from 'lucide-react';

export const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const data = await apiClient('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });

      login(data.token, data.user);
      
      if (data.user.role === 'admin') {
        navigate('/admin/dashboard');
      } else {
        navigate('/student/dashboard');
      }
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء تسجيل الدخول');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
      <div className="mb-8 flex flex-col items-center">
        <div className="bg-blue-600 p-4 rounded-full mb-4">
          <GraduationCap className="w-12 h-12 text-white" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">منصة التعليم الإلكتروني</h1>
        <p className="text-gray-500 mt-2 text-center max-w-sm">
          مرحباً بك في المنصة. يرجى تسجيل الدخول للوصول إلى دوراتك أو إدارة المنصة.
        </p>
      </div>

      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-xl text-center">تسجيل الدخول</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="p-3 bg-red-50 text-red-600 rounded-md text-sm">
                {error}
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">اسم المستخدم</label>
              <Input 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="أدخل اسم المستخدم"
                required
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">كلمة المرور</label>
              <Input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>

            <Button 
              type="submit" 
              className="w-full mt-6" 
              disabled={isLoading}
            >
              {isLoading ? 'جاري الدخول...' : 'تسجيل الدخول'}
            </Button>
            
            <div className="mt-4 text-xs text-gray-500 text-center space-y-1 bg-gray-100 p-3 rounded-md">
              <p><strong>للتجربة:</strong></p>
              <p>المدير: admin / 123</p>
              <p>الطالب: student / 123</p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
