import { createBrowserRouter, Navigate, Outlet } from "react-router";
import { useAuth } from './context/AuthContext';

import { Login } from './pages/Login';
import { AdminLayout } from './pages/admin/Layout';
import { AdminDashboard } from './pages/admin/Dashboard';
import { AdminStudents } from './pages/admin/Students';
import { AdminCourses } from './pages/admin/Courses';

import { StudentLayout } from './pages/student/Layout';
import { StudentDashboard } from './pages/student/Dashboard';
import { StudentCourseView } from './pages/student/CourseView';

const ProtectedRoute = ({ allowedRole }: { allowedRole?: 'admin' | 'student' }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-gray-50 text-blue-600 font-bold">جاري التحميل...</div>;
  }

  if (!user) {
    return <Navigate to="/" replace />;
  }

  if (allowedRole && user.role !== allowedRole) {
    return <Navigate to={user.role === 'admin' ? '/admin/dashboard' : '/student/dashboard'} replace />;
  }

  return <Outlet />;
};

export const router = createBrowserRouter([
  {
    path: "/",
    Component: () => {
      const { user, loading } = useAuth();
      if (loading) return <div className="min-h-screen flex items-center justify-center bg-gray-50 text-blue-600 font-bold">جاري التحميل...</div>;
      if (user) {
        return <Navigate to={user.role === 'admin' ? '/admin/dashboard' : '/student/dashboard'} replace />;
      }
      return <Login />;
    },
  },
  {
    path: "/admin",
    element: <ProtectedRoute allowedRole="admin" />,
    children: [
      {
        element: <AdminLayout />,
        children: [
          { path: "dashboard", Component: AdminDashboard },
          { path: "students", Component: AdminStudents },
          { path: "courses", Component: AdminCourses },
          // Add default redirect
          { index: true, element: <Navigate to="dashboard" replace /> }
        ]
      }
    ]
  },
  {
    path: "/student",
    element: <ProtectedRoute allowedRole="student" />,
    children: [
      {
        element: <StudentLayout />,
        children: [
          { path: "dashboard", Component: StudentDashboard },
          { path: "course/:id", Component: StudentCourseView },
          { index: true, element: <Navigate to="dashboard" replace /> }
        ]
      }
    ]
  },
  {
    path: "*",
    Component: () => <div className="p-8 text-center text-red-500 font-bold">الصفحة غير موجودة 404</div>
  }
]);
