import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', logger(console.log));
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization', 'x-user-token'],
}));

// Route Prefix matching Make environment routing
const api = app.basePath('/make-server-6b96b9d8/api');

// --- SEED DB IF EMPTY ---
async function seedDB() {
  const users = await kv.getByPrefix('user:');
  if (users.length === 0) {
    console.log("Seeding database...");
    const keys = [
      'user:admin1',
      'user:student1',
      'course:c1',
      'course:c2',
      'enrollment:student1:c1',
      'enrollment:student1:c2'
    ];
    const values = [
      { id: 'admin1', username: 'admin', password: '123', role: 'admin', name: 'المدير العام' },
      { id: 'student1', username: 'student', password: '123', role: 'student', name: 'أحمد محمد' },
      { 
        id: 'c1', 
        title: 'دورة تطوير الويب الشاملة', 
        description: 'تعلم تطوير الويب من الصفر حتى الاحتراف باستخدام React و Node.js', 
        instructor: 'أحمد عمر', 
        price: 150,
        thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        sections: [
          { id: 's1', title: 'مقدمة في تطوير الويب', lessons: [
            { id: 'l1', title: 'ما هو تطوير الويب؟', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '5:30' },
            { id: 'l2', title: 'إعداد بيئة العمل', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '12:00' }
          ]},
          { id: 's2', title: 'أساسيات React', lessons: [
            { id: 'l3', title: 'المكونات (Components)', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '15:45' },
            { id: 'l4', title: 'الحالة (State)', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '20:10' }
          ]}
        ]
      },
      { 
        id: 'c2', 
        title: 'أساسيات التسويق الرقمي', 
        description: 'تعلم كيفية تسويق منتجاتك وخدماتك عبر الإنترنت بكفاءة عالية.', 
        instructor: 'سارة خالد', 
        price: 90,
        thumbnail: 'https://images.unsplash.com/photo-1557838923-2985c318be48?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        sections: [
          { id: 's3', title: 'مقدمة', lessons: [
            { id: 'l5', title: 'ما هو التسويق الرقمي؟', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '8:20' }
          ]}
        ]
      },
      { studentId: 'student1', courseId: 'c1', progress: 0 },
      { studentId: 'student1', courseId: 'c2', progress: 50 }
    ];
    await kv.mset(keys, values);
    console.log("Database seeded.");
  }
}
seedDB();

// --- MIDDLEWARE: AUTH (MOCK JWT) ---
// For the prototype, we pass user ID in the x-user-token header
const requireAuth = async (c: any, next: any) => {
  const token = c.req.header('x-user-token');
  if (!token) {
    return c.json({ error: 'Unauthorized' }, 401);
  }
  const user = await kv.get(`user:${token}`);
  if (!user) {
    return c.json({ error: 'Invalid token' }, 401);
  }
  c.set('user', user);
  await next();
};

const requireAdmin = async (c: any, next: any) => {
  const user = c.get('user');
  if (user.role !== 'admin') {
    return c.json({ error: 'Forbidden. Admin only.' }, 403);
  }
  await next();
};

// --- ROUTES ---

// Auth
api.post('/auth/login', async (c) => {
  try {
    const { username, password } = await c.req.json();
    const users = await kv.getByPrefix('user:');
    const user = users.find((u: any) => u.username === username && u.password === password);
    
    if (user) {
      // Mocking token as user.id for simplicity
      const { password, ...userWithoutPassword } = user;
      return c.json({ token: user.id, user: userWithoutPassword });
    }
    return c.json({ error: 'خطأ في اسم المستخدم أو كلمة المرور' }, 401);
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

api.get('/auth/me', requireAuth, async (c) => {
  const user = c.get('user');
  const { password, ...userWithoutPassword } = user;
  return c.json({ user: userWithoutPassword });
});

// Admin Stats
api.get('/admin/stats', requireAuth, requireAdmin, async (c) => {
  const users = await kv.getByPrefix('user:');
  const courses = await kv.getByPrefix('course:');
  
  const studentsCount = users.filter((u: any) => u.role === 'student').length;
  const totalRevenue = courses.reduce((sum: number, course: any) => sum + (course.price || 0), 0) * studentsCount; // Mock calculation
  
  return c.json({
    students: studentsCount,
    courses: courses.length,
    revenue: totalRevenue,
    instructorsEarnings: totalRevenue * 0.7 // Assuming 70% goes to instructor
  });
});

// Admin Users (Students)
api.get('/admin/users', requireAuth, requireAdmin, async (c) => {
  const users = await kv.getByPrefix('user:');
  const students = users.filter((u: any) => u.role === 'student').map(({ password, ...rest }: any) => rest);
  return c.json(students);
});

api.post('/admin/users', requireAuth, requireAdmin, async (c) => {
  const body = await c.req.json();
  const id = `student_${Date.now()}`;
  const newUser = { id, role: 'student', ...body };
  await kv.set(`user:${id}`, newUser);
  
  const { password, ...safeUser } = newUser;
  return c.json(safeUser, 201);
});

// Admin Courses
api.get('/admin/courses', requireAuth, requireAdmin, async (c) => {
  const courses = await kv.getByPrefix('course:');
  return c.json(courses);
});

api.post('/admin/courses', requireAuth, requireAdmin, async (c) => {
  const body = await c.req.json();
  const id = `course_${Date.now()}`;
  const newCourse = { id, sections: [], ...body };
  await kv.set(`course:${id}`, newCourse);
  return c.json(newCourse, 201);
});

// Student Courses
api.get('/student/courses', requireAuth, async (c) => {
  const user = c.get('user');
  const enrollments = await kv.getByPrefix(`enrollment:${user.id}:`);
  
  const courses = [];
  for (const en of enrollments) {
    const course = await kv.get(`course:${en.courseId}`);
    if (course) {
      courses.push({ ...course, progress: en.progress });
    }
  }
  
  return c.json(courses);
});

// Get Single Course
api.get('/courses/:id', requireAuth, async (c) => {
  const { id } = c.req.param();
  const course = await kv.get(`course:${id}`);
  if (!course) {
    return c.json({ error: 'Course not found' }, 404);
  }
  return c.json(course);
});

// Enroll User (Admin feature)
api.post('/admin/enrollments', requireAuth, requireAdmin, async (c) => {
  const { studentId, courseId } = await c.req.json();
  const enrollmentKey = `enrollment:${studentId}:${courseId}`;
  await kv.set(enrollmentKey, { studentId, courseId, progress: 0 });
  return c.json({ success: true, message: 'Student enrolled successfully' });
});

Deno.serve(app.fetch);